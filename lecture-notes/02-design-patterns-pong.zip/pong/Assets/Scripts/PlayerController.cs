using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [SerializeField] private bool isLeftPaddle = true;
    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private float speed = 2f;

    private float direction;

    // Update is called once per frame
    void Update()
    {
        if (isLeftPaddle)
        {
            if (Input.GetKey(KeyCode.W))
            {
                direction = 1f;
            }
            else if (Input.GetKey(KeyCode.S))
            {
                direction = -1f;
            }
            else
            {
                direction = 0f;
            }
        } 
        else 
        {
            if (Input.GetKey(KeyCode.UpArrow))
            {
                direction = 1f;
            }
            else if (Input.GetKey(KeyCode.DownArrow))
            {
                direction = -1f;
            }
            else
            {
                direction = 0f;
            }
        }

        rb.velocity = new Vector2(0, direction) * speed;
    }
}
