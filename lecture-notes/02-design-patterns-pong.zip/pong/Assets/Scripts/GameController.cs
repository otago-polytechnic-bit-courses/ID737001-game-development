using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class GameController : MonoBehaviour
{
    private int leftPaddleScore = 0;
    private int rightPaddleScore = 0;

    [SerializeField] TextMeshProUGUI leftPaddleScoreText;
    [SerializeField] TextMeshProUGUI rightPaddleScoreText;

    public void LeftPaddleScored()
    {
        leftPaddleScore++;
        leftPaddleScoreText.text = leftPaddleScore.ToString();
    }

    public void RightPaddleScored()
    {
        rightPaddleScore++;
        rightPaddleScoreText.text = rightPaddleScore.ToString();
    }
}
