using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoalController : MonoBehaviour
{
    [SerializeField] private bool isLeftPaddle;
    [SerializeField] private BallController ball;
    [SerializeField] private GameController game;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Ball"))
        {
            if (!isLeftPaddle)
            {
                game.LeftPaddleScored();
            }
            else
            {
                game.RightPaddleScored();
            }
            ball.Reset();
        }
    }
}
