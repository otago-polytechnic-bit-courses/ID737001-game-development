using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallController : MonoBehaviour
{
    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private float speed;

    // Start is called before the first frame update
    void Start()
    {
        Reset();
    }

    public void Reset() 
    {
        transform.position = Vector3.zero;

        float x = 0;
        float y = 0;

        int randNum = Random.Range(0, 4);

        if (randNum == 0)
        {
            x = 1f;
            y = 1f;
        }
        else if (randNum == 1)
        {
            x = 1f;
            y = -1f;
        }
        else if (randNum == 2)
        {
            x = -1f;
            y = 1f;
        }
        else if (randNum == 3)
        {
            x = -1f;
            y = -1f;
        }

        rb.velocity = new Vector2(x, y) * speed;
    }
}
